var sync_suggest_script = document.createElement('script'); 
sync_suggest_script.src = '//pro.syncsearch.jp/common/js/sync_suggest.js'; 
sync_suggest_script.type = 'text/javascript'; 
document.body.appendChild(sync_suggest_script);
SYNCSEARCH_SITE="P5HK2TBJ";
SYNCSEARCH_GROUP=9;